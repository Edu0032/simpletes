/* eslint-disable no-restricted-globals */
let pyodide = null;
let manifest = null;
let parserModule = null;
let initPromise = null;
let workerState = 'idle';
let activeParsePath = null;
const openDocumentIds = new Set();

function setState(state, detail = {}) {
  workerState = state;
  self.postMessage({ type: 'status', stage: state, state, openDocuments: openDocumentIds.size, ...detail });
}

function buildWorkerError(code, message, detail = null, stack = null) {
  return { code, message, detail, stack };
}

async function loadManifest(manifestUrl) {
  setState('loading-manifest', { manifestUrl });
  const response = await fetch(manifestUrl, { cache: 'default' });
  if (!response.ok) {
    throw buildWorkerError('MANIFEST_LOAD_FAILED', `Falha ao carregar manifest do parser: ${response.status}`, { manifestUrl, status: response.status });
  }
  return response.json();
}

async function loadSourceArchive(sourceArchiveUrl) {
  setState('loading-parser-source', { sourceArchiveUrl });
  const response = await fetch(sourceArchiveUrl, { cache: 'default' });
  if (!response.ok) {
    throw buildWorkerError('PARSER_SOURCE_LOAD_FAILED', `Falha ao carregar código Python do parser: ${response.status}`, { sourceArchiveUrl, status: response.status });
  }
  return response.arrayBuffer();
}

function validateBaseOptions(options) {
  if (!options || typeof options !== 'object') {
    throw buildWorkerError('INVALID_OPTIONS', 'Campo options ausente ou inválido.');
  }
  for (const field of ['orcamento_inicio', 'orcamento_fim', 'composicoes_inicio', 'composicoes_fim']) {
    if (!(field in options)) {
      throw buildWorkerError('MISSING_REQUIRED_OPTIONS', 'Payload options incompleto.', { missingField: field });
    }
  }
}

function validateParsePayload(payload) {
  if (!payload || typeof payload !== 'object') {
    throw buildWorkerError('INVALID_PAYLOAD', 'Payload de parse ausente ou inválido.');
  }
  const { buffer, options } = payload;
  if (!buffer || !(buffer instanceof ArrayBuffer)) {
    throw buildWorkerError('PDF_NOT_PROVIDED', 'Nenhum PDF foi enviado ao worker.', { receivedType: buffer?.constructor?.name || typeof buffer });
  }
  validateBaseOptions(options);
}

function validateDocumentPayload(payload) {
  if (!payload || typeof payload !== 'object') {
    throw buildWorkerError('INVALID_PAYLOAD', 'Payload de documento ausente ou inválido.');
  }
  const documentId = String(payload.documentId || '').trim();
  if (!documentId) {
    throw buildWorkerError('DOCUMENT_ID_REQUIRED', 'documentId ausente para operação staged.');
  }
  validateBaseOptions(payload.options || {});
  return documentId;
}

async function initPyodideRuntime(options = {}) {
  if (pyodide) return;
  manifest = manifest || await loadManifest(options.manifestUrl || './manifest.json');
  const pyodideBaseUrl = options.pyodideBaseUrl || manifest.pyodideBaseUrl;
  setState('loading-runtime', { pyodideBaseUrl });
  importScripts(`${pyodideBaseUrl}pyodide.js`);
  pyodide = await loadPyodide({ indexURL: pyodideBaseUrl });

  const builtinPackages = manifest.builtinPackages || [];
  if (builtinPackages.length) {
    setState('loading-builtins', { packages: builtinPackages });
    await pyodide.loadPackage(builtinPackages);
  }

  setState('loading-micropip');
  await pyodide.loadPackage('micropip');
  const micropip = pyodide.pyimport('micropip');

  const packages = manifest.packages || [];
  if (packages.length) {
    setState('installing-python-packages', { packages });
    await micropip.install(packages);
  }
  micropip.destroy?.();

  const sourceArchiveUrl = options.sourceArchiveUrl || manifest.sourceArchive;
  const archiveBuffer = await loadSourceArchive(sourceArchiveUrl);
  pyodide.unpackArchive(archiveBuffer, 'zip');
  pyodide.runPython(`
import sys
if '.' not in sys.path:
    sys.path.insert(0, '.')
`);

  setState('importing-parser-entry', { entryModule: manifest.entryModule });
  parserModule = pyodide.pyimport(manifest.entryModule);
  setState('ready');
}

async function ensureInitialized(options = {}) {
  if (!initPromise) {
    initPromise = initPyodideRuntime(options).catch((error) => {
      initPromise = null;
      pyodide = null;
      parserModule = null;
      manifest = null;
      throw error;
    });
  }
  return initPromise;
}

function createTempPdfPath() {
  return `/tmp/upload-${Date.now()}-${Math.random().toString(36).slice(2)}.pdf`;
}

function toErrorPayload(error) {
  if (error && typeof error === 'object' && error.code && error.message) {
    return error;
  }
  return buildWorkerError('WORKER_RUNTIME_ERROR', error?.message || String(error), null, error?.stack || null);
}

async function callParserFunction(name, ...args) {
  const fn = parserModule?.[name];
  if (!fn) {
    throw buildWorkerError('PARSER_FUNCTION_NOT_FOUND', `Função Python não encontrada: ${name}`);
  }
  return await fn(...args);
}

async function runFileTask(payload, functionName, statusName) {
  validateParsePayload(payload);
  const { buffer, options } = payload;
  setState(statusName);
  const pdfPath = createTempPdfPath();
  activeParsePath = pdfPath;
  try {
    setState('writing-pdf-bytes', { sizeBytes: buffer.byteLength });
    pyodide.FS.writeFile(pdfPath, new Uint8Array(buffer));
    setState('running-parser', { task: functionName, pdfPath });
    const jsonString = await callParserFunction(functionName, pdfPath, JSON.stringify(options || {}));
    const result = JSON.parse(jsonString);
    if (result && result.status === 'error' && result.error) {
      throw buildWorkerError(result.error.code || 'PARSER_RUNTIME_ERROR', result.error.message || 'Falha ao processar o PDF.', result.error.detail || null);
    }
    setState('done', { task: functionName });
    return result;
  } finally {
    try {
      if (activeParsePath) pyodide.FS.unlink(activeParsePath);
    } catch (_e) {}
    activeParsePath = null;
  }
}

async function runOpenDocumentTask(payload) {
  validateParsePayload(payload);
  const { buffer, options } = payload;
  setState('opening-document');
  const pdfPath = createTempPdfPath();
  activeParsePath = pdfPath;
  try {
    setState('writing-pdf-bytes', { sizeBytes: buffer.byteLength });
    pyodide.FS.writeFile(pdfPath, new Uint8Array(buffer));
    const jsonString = await callParserFunction('open_document_file_json', pdfPath, JSON.stringify(options || {}));
    const result = JSON.parse(jsonString);
    if (result && result.status === 'error' && result.error) {
      throw buildWorkerError(result.error.code || 'PARSER_RUNTIME_ERROR', result.error.message || 'Falha ao abrir o documento.', result.error.detail || null);
    }
    const documentId = String(result?.document_id || '').trim();
    if (documentId) {
      openDocumentIds.add(documentId);
    }
    setState('document-opened', { documentId });
    return result;
  } finally {
    try {
      if (activeParsePath) pyodide.FS.unlink(activeParsePath);
    } catch (_e) {}
    activeParsePath = null;
  }
}

async function runDocumentTask(payload, functionName, statusName) {
  const documentId = validateDocumentPayload(payload);
  setState(statusName, { documentId });
  const jsonString = await callParserFunction(functionName, documentId, JSON.stringify(payload.options || {}));
  const result = JSON.parse(jsonString);
  if (result && result.status === 'error' && result.error) {
    throw buildWorkerError(result.error.code || 'PARSER_RUNTIME_ERROR', result.error.message || 'Falha ao processar o documento.', result.error.detail || null);
  }
  setState('done', { task: functionName, documentId });
  return result;
}

async function runMergeTask(payload) {
  if (!payload || typeof payload !== 'object') {
    throw buildWorkerError('INVALID_PAYLOAD', 'Payload de merge ausente ou inválido.');
  }
  validateBaseOptions(payload.options || {});
  setState('merging');
  const jsonString = await callParserFunction(
    'merge_stages_json',
    JSON.stringify(payload.budget || {}),
    JSON.stringify(payload.compositions || {}),
    JSON.stringify(payload.options || {})
  );
  const result = JSON.parse(jsonString);
  if (result && result.status === 'error' && result.error) {
    throw buildWorkerError(result.error.code || 'PARSER_RUNTIME_ERROR', result.error.message || 'Falha ao consolidar resultados.', result.error.detail || null);
  }
  setState('done', { task: 'merge' });
  return result;
}

async function runMergeDocumentTask(payload) {
  const documentId = validateDocumentPayload(payload);
  setState('merging-document', { documentId });
  const jsonString = await callParserFunction('merge_document_json', documentId, JSON.stringify(payload.options || {}));
  const result = JSON.parse(jsonString);
  if (result && result.status === 'error' && result.error) {
    throw buildWorkerError(result.error.code || 'PARSER_RUNTIME_ERROR', result.error.message || 'Falha ao consolidar documento staged.', result.error.detail || null);
  }
  setState('done', { task: 'merge-document', documentId });
  return result;
}

async function runCloseDocumentTask(payload) {
  const documentId = String(payload?.documentId || '').trim();
  if (!documentId) {
    throw buildWorkerError('DOCUMENT_ID_REQUIRED', 'documentId ausente para fechamento do documento.');
  }
  setState('closing-document', { documentId });
  const jsonString = await callParserFunction('close_document_json', documentId);
  const result = JSON.parse(jsonString);
  if (result && result.status === 'error' && result.error) {
    throw buildWorkerError(result.error.code || 'PARSER_RUNTIME_ERROR', result.error.message || 'Falha ao fechar o documento.', result.error.detail || null);
  }
  openDocumentIds.delete(documentId);
  setState('document-closed', { documentId });
  return result;
}

self.onmessage = async (event) => {
  const { type, payload } = event.data || {};
  try {
    if (type === 'init') {
      await ensureInitialized(payload || {});
      self.postMessage({ type: 'ready' });
      return;
    }

    if (type === 'parse' || type === 'parse-base') {
      await ensureInitialized(payload || {});
      const result = await runFileTask(payload || {}, 'parse_base_file_json', 'processing');
      self.postMessage({ type: 'result', payload: result });
      return;
    }

    if (type === 'parse-budget') {
      await ensureInitialized(payload || {});
      const result = await runFileTask(payload || {}, 'parse_budget_file_json', 'processing-budget');
      self.postMessage({ type: 'result', payload: result });
      return;
    }

    if (type === 'parse-compositions') {
      await ensureInitialized(payload || {});
      const result = await runFileTask(payload || {}, 'parse_compositions_file_json', 'processing-compositions');
      self.postMessage({ type: 'result', payload: result });
      return;
    }

    if (type === 'open-document') {
      await ensureInitialized(payload || {});
      const result = await runOpenDocumentTask(payload || {});
      self.postMessage({ type: 'result', payload: result });
      return;
    }

    if (type === 'parse-budget-document') {
      await ensureInitialized(payload || {});
      const result = await runDocumentTask(payload || {}, 'parse_budget_document_json', 'processing-budget');
      self.postMessage({ type: 'result', payload: result });
      return;
    }

    if (type === 'parse-compositions-document') {
      await ensureInitialized(payload || {});
      const result = await runDocumentTask(payload || {}, 'parse_compositions_document_json', 'processing-compositions');
      self.postMessage({ type: 'result', payload: result });
      return;
    }

    if (type === 'merge') {
      await ensureInitialized(payload || {});
      const result = await runMergeTask(payload || {});
      self.postMessage({ type: 'result', payload: result });
      return;
    }

    if (type === 'merge-document') {
      await ensureInitialized(payload || {});
      const result = await runMergeDocumentTask(payload || {});
      self.postMessage({ type: 'result', payload: result });
      return;
    }

    if (type === 'close-document') {
      await ensureInitialized(payload || {});
      const result = await runCloseDocumentTask(payload || {});
      self.postMessage({ type: 'result', payload: result });
      return;
    }

    if (type === 'get-state') {
      self.postMessage({ type: 'state', payload: { state: workerState, openDocuments: openDocumentIds.size } });
      return;
    }

    throw buildWorkerError('UNKNOWN_WORKER_MESSAGE', `Mensagem de worker desconhecida: ${type}`);
  } catch (error) {
    const payload = toErrorPayload(error);
    setState('error', { error: payload });
    self.postMessage({ type: 'error', payload });
  }
};
