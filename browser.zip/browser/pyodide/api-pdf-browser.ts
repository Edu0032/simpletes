export type BrowserParseOptions = {
  base_id?: string;
  orcamento_inicio: number;
  orcamento_fim: number;
  composicoes_inicio: number;
  composicoes_fim: number;
  obra_nome?: string;
  obra_localizacao?: string;
  orgao_nome?: string;
  prefeitura_nome?: string;
  contratante_nome?: string;
  dynamic_ignore_phrases?: string | string[];
  metadata_extraida_ia?: Record<string, unknown>;
  strict_validation?: boolean;
  filename?: string;
  content_type?: string;
  performance_profile?: 'browser_fast' | 'standard';
};

export type WorkerInitOptions = {
  workerUrl?: string;
  manifestUrl?: string;
  sourceArchiveUrl?: string;
  pyodideBaseUrl?: string;
};

export type WorkerStatusDetail = {
  stage: string;
  worker?: 'parser';
  state?: string;
  openDocuments?: number;
  documentId?: string;
  [key: string]: unknown;
};

export type BrowserDocumentHandle = {
  documentId: string;
  meta?: Record<string, unknown>;
};

export type BrowserPreviewPayload = {
  stage: 'preview_orcamento';
  status: 'partial';
  preview: true;
  base_id: string;
  orcamento_sintetico: any;
  meta: Record<string, unknown>;
};

export type BrowserPreviewHandlers = {
  onPreview?: (payload: BrowserPreviewPayload) => void | Promise<void>;
};

const PARSER_RELEASE = 'v56.3';
const BROWSER_CONTRACT_VERSION = 'browser.v56.3';
const BROWSER_INTEGRATION_TARGET = 'lovable';

function validateOptions(options: Omit<BrowserParseOptions, 'filename' | 'content_type'>) {
  const required = ['orcamento_inicio', 'orcamento_fim', 'composicoes_inicio', 'composicoes_fim'] as const;
  for (const field of required) {
    const value = options[field];
    if (!Number.isInteger(value)) {
      throw new Error(`Campo inválido: ${field} precisa ser inteiro.`);
    }
  }
}

function normalizePayloadOptions(file: File, options: Omit<BrowserParseOptions, 'filename' | 'content_type'>): BrowserParseOptions {
  return {
    base_id: options.base_id || 'misto',
    performance_profile: options.performance_profile || 'browser_fast',
    ...options,
    filename: file.name,
    content_type: file.type || 'application/pdf',
  };
}

function buildBudgetPreviewPayload(file: File, options: Omit<BrowserParseOptions, 'filename' | 'content_type'>, budgetStagePayload: any): BrowserPreviewPayload {
  return {
    stage: 'preview_orcamento',
    status: 'partial',
    preview: true,
    base_id: String(budgetStagePayload?.base_id || options.base_id || 'misto'),
    orcamento_sintetico: budgetStagePayload?.orcamento_sintetico || { descricao: '', total: 0, itens_raiz: [], itens_plano: [] },
    meta: {
      parser_version: PARSER_RELEASE,
      contract_version: BROWSER_CONTRACT_VERSION,
      integration_target: BROWSER_INTEGRATION_TARGET,
      preview: true,
      preview_kind: 'orcamento_sintetico',
      filename: file.name,
      composicoes_pending: true,
      preview_stage_meta: budgetStagePayload?._stage_meta || {},
    },
  };
}

function workerRequest<T = any>(
  worker: Worker,
  type: string,
  payload: any,
  transfer: Transferable[] = [],
  onStatus?: (stage: string, detail: WorkerStatusDetail) => void,
): Promise<T> {
  return new Promise((resolve, reject) => {
    const onMessage = (event: MessageEvent) => {
      const { type: msgType, stage, payload: msgPayload, ...rest } = event.data || {};
      if (msgType === 'status') {
        onStatus?.(stage, { stage, worker: 'parser', ...(rest as WorkerStatusDetail) });
        return;
      }
      if (msgType === 'result' || msgType === 'ready') {
        worker.removeEventListener('message', onMessage);
        resolve(msgType === 'ready' ? undefined as T : msgPayload);
        return;
      }
      if (msgType === 'error') {
        worker.removeEventListener('message', onMessage);
        reject(new Error(msgPayload?.message || 'Falha no worker do parser.'));
      }
    };
    worker.addEventListener('message', onMessage);
    worker.postMessage({ type, payload }, transfer);
  });
}

export class ApiPdfBrowserClient {
  private worker!: Worker;
  private readyPromise!: Promise<void>;
  private statusHandler?: (stage: string, detail: WorkerStatusDetail) => void;
  private initOptions: WorkerInitOptions;

  constructor(options: WorkerInitOptions = {}, onStatus?: (stage: string, detail: WorkerStatusDetail) => void) {
    this.initOptions = options;
    this.statusHandler = onStatus;
    this.createWorker();
  }

  private createOneWorker(): Worker {
    const workerUrl = this.initOptions.workerUrl || '/browser/pyodide/pyodide-parser-worker.js';
    return new Worker(workerUrl, { type: 'classic' });
  }

  private createWorker() {
    this.worker = this.createOneWorker();
    this.readyPromise = workerRequest(this.worker, 'init', this.initOptions, [], this.statusHandler).then(() => undefined);
  }

  async ready(): Promise<void> {
    return this.readyPromise;
  }

  private async runFileTask(file: File, options: Omit<BrowserParseOptions, 'filename' | 'content_type'>, type: 'parse' | 'parse-base' | 'parse-budget' | 'parse-compositions'): Promise<any> {
    validateOptions(options);
    await this.ready();
    const buffer = await file.arrayBuffer();
    const payloadOptions = normalizePayloadOptions(file, options);
    return workerRequest(this.worker, type, { buffer, options: payloadOptions }, [buffer], this.statusHandler);
  }

  async parse(file: File, options: Omit<BrowserParseOptions, 'filename' | 'content_type'>): Promise<any> {
    return this.runFileTask(file, options, 'parse-base');
  }

  async parseBase(file: File, options: Omit<BrowserParseOptions, 'filename' | 'content_type'>): Promise<any> {
    return this.runFileTask(file, options, 'parse-base');
  }

  async parseBudgetStage(file: File, options: Omit<BrowserParseOptions, 'filename' | 'content_type'>): Promise<any> {
    return this.runFileTask(file, options, 'parse-budget');
  }

  async parseCompositionsStage(file: File, options: Omit<BrowserParseOptions, 'filename' | 'content_type'>): Promise<any> {
    return this.runFileTask(file, options, 'parse-compositions');
  }

  async openDocument(file: File, options: Omit<BrowserParseOptions, 'filename' | 'content_type'>): Promise<BrowserDocumentHandle> {
    validateOptions(options);
    await this.ready();
    const buffer = await file.arrayBuffer();
    const payloadOptions = normalizePayloadOptions(file, options);
    const opened = await workerRequest<any>(this.worker, 'open-document', { buffer, options: payloadOptions }, [buffer], this.statusHandler);
    return {
      documentId: String(opened?.document_id || ''),
      meta: opened?.meta || {},
    };
  }

  async closeDocument(documentId: string): Promise<void> {
    await this.ready();
    await workerRequest(this.worker, 'close-document', { documentId }, [], this.statusHandler);
  }

  async parseBudgetStageFromDocument(documentId: string, options: Omit<BrowserParseOptions, 'filename' | 'content_type'>): Promise<any> {
    validateOptions(options);
    await this.ready();
    return workerRequest(this.worker, 'parse-budget-document', { documentId, options }, [], this.statusHandler);
  }

  async parseCompositionsStageFromDocument(documentId: string, options: Omit<BrowserParseOptions, 'filename' | 'content_type'>): Promise<any> {
    validateOptions(options);
    await this.ready();
    return workerRequest(this.worker, 'parse-compositions-document', { documentId, options }, [], this.statusHandler);
  }

  async mergeDocumentStages(documentId: string, options: Omit<BrowserParseOptions, 'filename' | 'content_type'>): Promise<any> {
    validateOptions(options);
    await this.ready();
    return workerRequest(this.worker, 'merge-document', { documentId, options }, [], this.statusHandler);
  }

  async parseWithPreview(
    file: File,
    options: Omit<BrowserParseOptions, 'filename' | 'content_type'>,
    handlers: BrowserPreviewHandlers = {},
  ): Promise<{ preview: BrowserPreviewPayload; final: any; budgetStage: any; compositionsStage: any; document: BrowserDocumentHandle; }> {
    const document = await this.openDocument(file, options);
    try {
      const budgetStage = await this.parseBudgetStageFromDocument(document.documentId, options);
      const preview = buildBudgetPreviewPayload(file, options, budgetStage);
      this.statusHandler?.('preview-ready', { stage: 'preview-ready', worker: 'parser', preview: true, documentId: document.documentId });
      if (handlers.onPreview) {
        await handlers.onPreview(preview);
      }
      const compositionsStage = await this.parseCompositionsStageFromDocument(document.documentId, options);
      this.statusHandler?.('finalizing', { stage: 'finalizing', worker: 'parser', documentId: document.documentId });
      const final = await this.mergeDocumentStages(document.documentId, options);
      return { preview, final, budgetStage, compositionsStage, document };
    } finally {
      if (document.documentId) {
        await this.closeDocument(document.documentId).catch(() => undefined);
      }
    }
  }

  async mergeStages(budgetPayload: any, compositionsPayload: any, options: Omit<BrowserParseOptions, 'filename' | 'content_type'>): Promise<any> {
    validateOptions(options);
    await this.ready();
    return workerRequest(
      this.worker,
      'merge',
      {
        budget: budgetPayload,
        compositions: compositionsPayload,
        options: {
          base_id: options.base_id || 'misto',
          performance_profile: options.performance_profile || 'browser_fast',
          ...options,
          filename: 'upload.pdf',
          content_type: 'application/pdf',
        },
      },
      [],
      this.statusHandler,
    );
  }

  reset(): void {
    this.worker.terminate();
    this.createWorker();
  }

  cancelCurrent(): void {
    this.reset();
  }

  terminate(): void {
    this.worker.terminate();
  }
}
